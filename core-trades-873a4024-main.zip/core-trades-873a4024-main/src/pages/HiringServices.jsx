import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { 
  CheckCircle, 
  Users, 
  Briefcase, 
  ChevronDown,
  ArrowRight,
  Target,
  Zap,
  TrendingUp,
  Clock
} from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

export default function HiringServices() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    async function loadUser() {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      } catch (error) {
        setUser(null);
      } finally {
        setLoading(false);
      }
    }
    loadUser();
  }, []);

  // SEO Meta Tags
  useEffect(() => {
    document.title = 'Founding 50 Hiring Partners - CoreTrades | Lock in Lifetime Pricing at $34.99/mo';
    
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute('content', 'CoreTrades connects Canadian employers with verified trades talent. Founding 50 Employers can lock in lifetime hiring access for just $34.99/month.');
    } else {
      const meta = document.createElement('meta');
      meta.name = 'description';
      meta.content = 'CoreTrades connects Canadian employers with verified trades talent. Founding 50 Employers can lock in lifetime hiring access for just $34.99/month.';
      document.head.appendChild(meta);
    }

    const metaKeywords = document.querySelector('meta[name="keywords"]');
    if (metaKeywords) {
      metaKeywords.setAttribute('content', 'founding 50, ICI trades hiring, affordable job posting, lifetime pricing, post trades jobs, hire electricians, hire welders, skilled trades recruitment, CoreTrades hiring');
    } else {
      const meta = document.createElement('meta');
      meta.name = 'keywords';
      meta.content = 'founding 50, ICI trades hiring, affordable job posting, lifetime pricing, post trades jobs, hire electricians, hire welders, skilled trades recruitment, CoreTrades hiring';
      document.head.appendChild(meta);
    }

    const ogTitle = document.querySelector('meta[property="og:title"]');
    if (ogTitle) {
      ogTitle.setAttribute('content', 'Founding 50 Hiring Partners - CoreTrades | Lifetime Pricing $34.99/mo');
    } else {
      const meta = document.createElement('meta');
      meta.setAttribute('property', 'og:title');
      meta.content = 'Founding 50 Hiring Partners - CoreTrades | Lifetime Pricing $34.99/mo';
      document.head.appendChild(meta);
    }

    const ogDescription = document.querySelector('meta[property="og:description"]');
    if (ogDescription) {
      ogDescription.setAttribute('content', 'Join the first 50 employers building the CoreTrades hiring network. Lock in $34.99/mo lifetime rate before standard pricing begins.');
    } else {
      const meta = document.createElement('meta');
      meta.setAttribute('property', 'og:description');
      meta.content = 'Join the first 50 employers building the CoreTrades hiring network. Lock in $34.99/mo lifetime rate before standard pricing begins.';
      document.head.appendChild(meta);
    }

    return () => {
      document.title = 'Core Trades Inc.';
    };
  }, []);

  const scrollToPricing = () => {
    document.getElementById('pricing-section')?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleJoinFounding50 = () => {
    if (!user) {
      base44.auth.redirectToLogin(createPageUrl('HiringServices'));
      return;
    }
    
    if (user.app_role !== 'employer' && user.app_role !== 'admin') {
      toast({
        title: "Employer Access Required",
        description: "Only employers can join the Founding 50. Please complete your profile as an employer.",
        variant: "destructive",
      });
      navigate(createPageUrl('CompleteProfile'));
      return;
    }

    setShowModal(true);
  };

  const handleConfirmPlan = async () => {
    try {
      const employers = await base44.entities.Employer.filter({ 
        memberEmails: [user.email]
      });

      if (employers.length === 0) {
        toast({
          title: "Error",
          description: "No organization found. Please complete your profile first.",
          variant: "destructive",
        });
        navigate(createPageUrl('CompleteProfile'));
        return;
      }

      const employer = employers[0];

      await base44.entities.Employer.update(employer.id, {
        plan: 'founding50',
        planSeats: null, // Unlimited seats for Founding 50
        planPostsRemaining: null, // Unlimited posts for Founding 50
        planViewsRemaining: null, // Unlimited views for Founding 50
        verified: false,
      });

      setShowModal(false);
      
      toast({
        title: "Welcome to the Founding 50!",
        description: "Your lifetime rate is locked in at $34.99/mo. Redirecting to post your first job...",
      });

      setTimeout(() => {
        navigate(createPageUrl('EmployerJobNew'));
      }, 1000);
    } catch (error) {
      console.error('Error activating plan:', error);
      toast({
        title: "Error",
        description: "Failed to activate plan. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#0a0a0a] to-[#1a1a1a] flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a0a0a] to-[#1a1a1a]">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-32 px-6">
        <div 
          className="absolute inset-0 opacity-5"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }}
        />
        
        <div className="max-w-5xl mx-auto text-center relative z-10">
          <div className="inline-block bg-[#f57c00]/20 border border-[#f57c00] rounded-full px-6 py-2 mb-6">
            <span className="text-[#f57c00] font-bold text-sm uppercase tracking-wide">Limited Time Offer</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-black mb-6 text-white tracking-tight">
            Founding 50 Hiring Partners
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-12 max-w-3xl mx-auto leading-relaxed">
            Lock in lifetime pricing at <span className="text-[#f57c00] font-bold">$34.99/month</span>. Hire proven trades talent. Simple, affordable, effective.
          </p>
          <Button 
            onClick={scrollToPricing}
            className="bg-[#f57c00] hover:bg-[#e65100] text-white text-lg px-12 py-7 rounded-xl font-bold shadow-[0_0_20px_#f57c00aa] hover:shadow-[0_0_30px_#f57c00cc] transition-all duration-300"
          >
            Join the Founding 50
            <ChevronDown className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </section>

      {/* Founding 50 Pricing Section */}
      <section id="pricing-section" className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4">
              Exclusive Founding Partner Pricing
            </h2>
            <p className="text-xl text-gray-400">
              Be part of the first 50 employers building the CoreTrades network.
            </p>
          </div>

          {/* Main Founding 50 Card */}
          <div className="max-w-2xl mx-auto mb-16">
            <Card className="relative bg-gradient-to-br from-[#f57c00] to-[#e65100] border-4 border-[#f57c00] shadow-[0_0_40px_#f57c00aa] transform hover:scale-105 transition-all duration-300">
              <div className="absolute -top-5 left-1/2 transform -translate-x-1/2 bg-white text-[#f57c00] text-sm font-black px-6 py-2 rounded-full shadow-lg uppercase tracking-wide">
                Founding 50 Members Only
              </div>
              
              <CardHeader className="pt-12 pb-6 text-center">
                <CardTitle className="text-4xl font-black text-white mb-4">
                  Founding 50 Hiring Partners
                </CardTitle>
                <div className="mb-6">
                  <span className="text-6xl font-black text-white">
                    $34.99
                  </span>
                  <span className="text-white text-2xl"> / month</span>
                  <div className="mt-2">
                    <span className="bg-white/20 text-white text-sm font-bold px-4 py-2 rounded-full">
                      Lifetime Rate Locked In
                    </span>
                  </div>
                </div>
                <p className="text-white/90 text-lg leading-relaxed max-w-xl mx-auto">
                  Join our first 50 employers building the CoreTrades hiring network. Post jobs, receive applicants, and access our recruitment tools at a lifetime discounted rate.
                </p>
                <p className="text-white/80 text-base mt-4 font-medium">
                  Once these 50 spots are filled, standard pricing begins at $79/month.
                </p>
              </CardHeader>

              <CardContent className="pb-12">
                <ul className="space-y-4 mb-8">
                  <li className="flex items-start gap-3">
                    <CheckCircle className="w-6 h-6 text-white mt-0.5 flex-shrink-0" />
                    <span className="text-white text-lg font-medium">Unlimited job posts</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle className="w-6 h-6 text-white mt-0.5 flex-shrink-0" />
                    <span className="text-white text-lg font-medium">Unlimited team seats</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle className="w-6 h-6 text-white mt-0.5 flex-shrink-0" />
                    <span className="text-white text-lg font-medium">Access to verified trades resumes</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle className="w-6 h-6 text-white mt-0.5 flex-shrink-0" />
                    <span className="text-white text-lg font-medium">In-platform candidate messaging</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle className="w-6 h-6 text-white mt-0.5 flex-shrink-0" />
                    <span className="text-white text-lg font-medium">Priority support</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle className="w-6 h-6 text-white mt-0.5 flex-shrink-0" />
                    <span className="text-white text-lg font-medium">Lifetime $34.99/mo rate guarantee</span>
                  </li>
                </ul>

                <Button
                  onClick={handleJoinFounding50}
                  className="w-full bg-white text-[#f57c00] hover:bg-gray-100 py-7 rounded-xl font-black text-xl shadow-lg hover:shadow-xl transition-all"
                >
                  Join the Founding 50 – $34.99/mo
                </Button>
                
                <p className="text-center text-white/90 text-sm mt-4 font-medium">
                  ⏰ 50 spots available — updating live
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Coming Soon Plans */}
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h3 className="text-3xl font-black text-white mb-3">Future Plans</h3>
              <p className="text-gray-400 text-lg">Additional tiers launching after Founding 50 is full</p>
            </div>

            <div className="grid md:grid-cols-3 gap-8 opacity-60">
              <Card className="bg-gradient-to-b from-[#1a1a1a] to-[#0a0a0a] border-2 border-[#424242] relative">
                <div className="absolute -top-3 right-6 bg-[#424242] text-white text-xs font-bold px-4 py-1 rounded-full">
                  COMING SOON
                </div>
                <CardHeader className="pb-4">
                  <CardTitle className="text-2xl font-black text-white mb-2">
                    Standard Plan
                  </CardTitle>
                  <div className="mt-4">
                    <span className="text-4xl font-black text-gray-400">
                      $79
                    </span>
                    <span className="text-gray-400 text-lg"> / month</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 text-gray-400">
                    <li className="flex items-start gap-2">
                      <CheckCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
                      <span>1 active job post</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
                      <span>Resume inbox</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
                      <span>Basic analytics</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-b from-[#1a1a1a] to-[#0a0a0a] border-2 border-[#424242] relative">
                <div className="absolute -top-3 right-6 bg-[#424242] text-white text-xs font-bold px-4 py-1 rounded-full">
                  COMING SOON
                </div>
                <CardHeader className="pb-4">
                  <CardTitle className="text-2xl font-black text-white mb-2">
                    Premium Plan
                  </CardTitle>
                  <div className="mt-4">
                    <span className="text-4xl font-black text-gray-400">
                      $119
                    </span>
                    <span className="text-gray-400 text-lg"> / month</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 text-gray-400">
                    <li className="flex items-start gap-2">
                      <CheckCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
                      <span>Priority job listings</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
                      <span>Multiple job posts</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
                      <span>Resume search access</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-b from-[#1a1a1a] to-[#0a0a0a] border-2 border-[#424242] relative">
                <div className="absolute -top-3 right-6 bg-[#424242] text-white text-xs font-bold px-4 py-1 rounded-full">
                  COMING SOON
                </div>
                <CardHeader className="pb-4">
                  <CardTitle className="text-2xl font-black text-white mb-2">
                    Pro Campaign Plan
                  </CardTitle>
                  <div className="mt-4">
                    <span className="text-4xl font-black text-gray-400">
                      $249
                    </span>
                    <span className="text-gray-400 text-lg"> / month</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 text-gray-400">
                    <li className="flex items-start gap-2">
                      <CheckCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
                      <span>Job postings included</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
                      <span>Targeted Meta ads</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
                      <span>TikTok ad campaigns</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Why Join Section */}
      <section className="py-20 px-6 bg-[#0a0a0a]">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-black text-white text-center mb-16">
            Why Join the Founding 50?
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-gradient-to-b from-[#1a1a1a] to-[#0a0a0a] border border-[#424242] rounded-xl p-8 text-center hover:border-[#f57c00] transition-all">
              <div className="w-16 h-16 bg-[#f57c00]/20 rounded-xl flex items-center justify-center mx-auto mb-6">
                <Zap className="w-8 h-8 text-[#f57c00]" />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">Lifetime Rate Lock</h3>
              <p className="text-gray-400">Your $34.99/mo rate never increases. Ever.</p>
            </div>

            <div className="bg-gradient-to-b from-[#1a1a1a] to-[#0a0a0a] border border-[#424242] rounded-xl p-8 text-center hover:border-[#f57c00] transition-all">
              <div className="w-16 h-16 bg-[#f57c00]/20 rounded-xl flex items-center justify-center mx-auto mb-6">
                <Users className="w-8 h-8 text-[#f57c00]" />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">Unlimited Everything</h3>
              <p className="text-gray-400">No caps on posts, seats, or candidate views.</p>
            </div>

            <div className="bg-gradient-to-b from-[#1a1a1a] to-[#0a0a0a] border border-[#424242] rounded-xl p-8 text-center hover:border-[#f57c00] transition-all">
              <div className="w-16 h-16 bg-[#f57c00]/20 rounded-xl flex items-center justify-center mx-auto mb-6">
                <Target className="w-8 h-8 text-[#f57c00]" />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">ICI-Focused Network</h3>
              <p className="text-gray-400">Reach verified trades professionals only.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-black text-white text-center mb-16">
            Trusted by ICI Contractors
          </h2>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-gradient-to-b from-[#1a1a1a] to-[#0a0a0a] border border-[#424242] rounded-xl p-8 hover:border-[#f57c00] transition-all">
              <div className="flex gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <span key={i} className="text-[#f57c00] text-xl">★</span>
                ))}
              </div>
              <p className="text-gray-300 text-lg mb-6 leading-relaxed">
                "We filled our shutdown crew in under a week. CoreTrades saves me hours."
              </p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-[#f57c00]/20 rounded-full flex items-center justify-center">
                  <span className="text-[#f57c00] font-bold">RM</span>
                </div>
                <div>
                  <p className="text-white font-bold">Ryan M.</p>
                  <p className="text-gray-400 text-sm">Maintenance Manager, Alberta</p>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-b from-[#1a1a1a] to-[#0a0a0a] border border-[#424242] rounded-xl p-8 hover:border-[#f57c00] transition-all">
              <div className="flex gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <span key={i} className="text-[#f57c00] text-xl">★</span>
                ))}
              </div>
              <p className="text-gray-300 text-lg mb-6 leading-relaxed">
                "Finally, a hiring tool that actually knows construction."
              </p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-[#f57c00]/20 rounded-full flex items-center justify-center">
                  <span className="text-[#f57c00] font-bold">KL</span>
                </div>
                <div>
                  <p className="text-white font-bold">Kim L.</p>
                  <p className="text-gray-400 text-sm">HR Lead, Ontario</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Footer */}
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto text-center bg-gradient-to-r from-[#f57c00] to-[#e65100] rounded-2xl p-12 shadow-[0_0_40px_#f57c00aa]">
          <h2 className="text-4xl font-black text-white mb-6">
            Lock in your lifetime rate today.
          </h2>
          <p className="text-white/90 text-xl mb-8">
            Founding 50 pricing available only until launch. Don't miss out.
          </p>
          <Button 
            onClick={scrollToPricing}
            className="bg-white text-[#f57c00] hover:bg-gray-100 text-lg px-12 py-7 rounded-xl font-bold shadow-lg hover:shadow-xl transition-all"
          >
            Join the Founding 50
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </section>

      {/* Plan Selection Modal */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="bg-[#0a0a0a] border-[#424242] text-white">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-white">
              Join the Founding 50
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-6">
            <div className="bg-[#1a1a1a] border border-[#424242] rounded-xl p-6">
              <p className="text-gray-400 mb-2">Selected Plan:</p>
              <p className="text-2xl font-black text-[#f57c00]">
                Founding 50 – $34.99/mo (Lifetime)
              </p>
            </div>
            
            <div className="bg-[#1a1a1a] border border-[#424242] rounded-xl p-4">
              <p className="text-sm text-gray-400 text-center">
                🔒 This is a placeholder billing flow. No payment will be processed.
              </p>
            </div>

            <Button
              onClick={handleConfirmPlan}
              className="w-full bg-gradient-to-r from-[#f57c00] to-[#e65100] hover:from-[#e65100] hover:to-[#d84315] text-white py-6 text-lg font-bold rounded-xl shadow-[0_0_15px_#f57c00aa]"
            >
              Activate Plan & Start Hiring
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}