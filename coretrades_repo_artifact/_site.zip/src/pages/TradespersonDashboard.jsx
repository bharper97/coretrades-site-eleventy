
import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { FileText, Briefcase, Bookmark, Plus, Trash2, Loader2 } from 'lucide-react';
import ProtectedRoute from '@/components/ProtectedRoute';
import { useToast } from '@/components/ui/use-toast';

function TradespersonDashboardContent() {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [resumeData, setResumeData] = useState({
    headline: '',
    summary: '',
    tickets: [],
    experience: []
  });
  const [newTicket, setNewTicket] = useState('');
  const [newExperience, setNewExperience] = useState({
    role: '',
    siteType: '',
    employer: '',
    from: '',
    to: '',
    notes: ''
  });

  // Determine active tab from hash
  const [activeTab, setActiveTab] = useState('applications');
  useEffect(() => {
    const hash = location.hash.replace('#', '');
    if (hash === 'applied' || hash === 'saved' || hash === 'resume' || hash === 'account') {
      setActiveTab(hash === 'applied' ? 'applications' : hash);
    }
  }, [location.hash]);

  useEffect(() => {
    async function loadUser() {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
        
        const profiles = await base44.entities.Profile.filter({ created_by: currentUser.email });
        if (profiles.length > 0) {
          setProfile(profiles[0]);

          // Load resume
          const resumes = await base44.entities.Resume.filter({ userId: profiles[0].id });
          if (resumes.length > 0) {
            setResumeData(resumes[0]);
          }
        }
      } catch (error) {
        console.error('Error loading user:', error);
      }
    }
    loadUser();
  }, []);

  const { data: applications = [] } = useQuery({
    queryKey: ['tradesperson-applications', profile?.id],
    queryFn: async () => {
      if (!profile) return [];
      const apps = await base44.entities.Application.filter({ candidateId: profile.id });
      
      // Fetch job details for each application
      const jobIds = apps.map(app => app.jobId);
      const jobs = await Promise.all(
        jobIds.map(id => base44.entities.Job.filter({ id }).then(j => j[0]))
      );
      
      return apps.map((app, index) => ({
        ...app,
        job: jobs[index]
      }));
    },
    enabled: !!profile
  });

  const { data: savedJobs = [] } = useQuery({
    queryKey: ['tradesperson-saved-jobs', profile?.id],
    queryFn: async () => {
      if (!profile) return [];
      const saved = await base44.entities.SavedJob.filter({ userId: profile.id });
      
      // Fetch job details
      const jobIds = saved.map(s => s.jobId);
      const jobs = await Promise.all(
        jobIds.map(id => base44.entities.Job.filter({ id }).then(j => j[0]))
      );
      
      return saved.map((s, index) => ({
        ...s,
        job: jobs[index]
      })).filter(s => s.job); // Filter out deleted jobs
    },
    enabled: !!profile
  });

  const saveResumeMutation = useMutation({
    mutationFn: async () => {
      if (!profile) throw new Error('Profile not found');
      
      const resumes = await base44.entities.Resume.filter({ userId: profile.id });
      if (resumes.length > 0) {
        return await base44.entities.Resume.update(resumes[0].id, resumeData);
      } else {
        return await base44.entities.Resume.create({
          ...resumeData,
          userId: profile.id
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['tradesperson-resume']);
      toast({
        title: "Resume Saved",
        description: "Your resume has been updated successfully",
      });
    },
  });

  const unsaveJobMutation = useMutation({
    mutationFn: async (savedJobId) => {
      return await base44.entities.SavedJob.delete(savedJobId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['tradesperson-saved-jobs']);
      toast({
        title: "Job Unsaved",
        description: "Removed from your saved jobs",
      });
    },
  });

  const handleAddTicket = () => {
    if (newTicket.trim()) {
      setResumeData({
        ...resumeData,
        tickets: [...(resumeData.tickets || []), newTicket.trim()]
      });
      setNewTicket('');
    }
  };

  const handleRemoveTicket = (index) => {
    setResumeData({
      ...resumeData,
      tickets: resumeData.tickets.filter((_, i) => i !== index)
    });
  };

  const handleAddExperience = () => {
    if (newExperience.role.trim()) {
      setResumeData({
        ...resumeData,
        experience: [...(resumeData.experience || []), { ...newExperience }]
      });
      setNewExperience({
        role: '',
        siteType: '',
        employer: '',
        from: '',
        to: '',
        notes: ''
      });
    }
  };

  const handleRemoveExperience = (index) => {
    setResumeData({
      ...resumeData,
      experience: resumeData.experience.filter((_, i) => i !== index)
    });
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'new': return 'bg-blue-500/20 text-blue-400';
      case 'reviewed': return 'bg-yellow-500/20 text-yellow-400';
      case 'shortlisted': return 'bg-green-500/20 text-green-400';
      case 'rejected': return 'bg-red-500/20 text-red-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  return (
    <div className="min-h-screen bg-[#1a1a1a] py-12 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2 text-white">Tradesperson Dashboard</h1>
          <p className="text-gray-400">Welcome back, {user?.full_name}</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-[#0a0a0a] border border-[#424242]">
            <TabsTrigger value="applications">
              Applied Jobs
              {applications.length > 0 && (
                <span className="ml-2 bg-[#f57c00] text-white text-xs px-2 py-0.5 rounded-full">
                  {applications.length}
                </span>
              )}
            </TabsTrigger>
            <TabsTrigger value="saved">
              Saved Jobs
              {savedJobs.length > 0 && (
                <span className="ml-2 bg-blue-500 text-white text-xs px-2 py-0.5 rounded-full">
                  {savedJobs.length}
                </span>
              )}
            </TabsTrigger>
            <TabsTrigger value="resume">Resume</TabsTrigger>
            <TabsTrigger value="account">Account</TabsTrigger>
          </TabsList>

          <TabsContent value="applications">
            <Card className="bg-[#0a0a0a] border-[#424242]">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Briefcase className="w-5 h-5 text-[#f57c00]" />
                  My Applications ({applications.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {applications.length === 0 ? (
                  <div className="text-center py-12">
                    <Briefcase className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                    <p className="text-gray-400 mb-4">You haven't applied to any jobs yet.</p>
                    <Link to={createPageUrl('JobBoard')}>
                      <Button className="bg-[#f57c00] hover:bg-[#e65100]">
                        Browse Job Board
                      </Button>
                    </Link>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {applications.map((app) => (
                      <div
                        key={app.id}
                        className="bg-[#1a1a1a] p-6 rounded-lg border border-[#424242] hover:border-[#f57c00] transition-all"
                      >
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <h3 className="text-xl font-bold text-white mb-1">
                              {app.job?.title || 'Job Deleted'}
                            </h3>
                            <p className="text-gray-300">{app.job?.company || 'N/A'}</p>
                          </div>
                          <Badge className={getStatusColor(app.status)}>
                            {app.status}
                          </Badge>
                        </div>
                        {app.job && (
                          <>
                            <p className="text-gray-400 text-sm mb-4">
                              Applied {new Date(app.created_date).toLocaleDateString()}
                            </p>
                            <Link to={`/job/${app.job.id}`}>
                              <Button
                                variant="outline"
                                className="border-white/20 text-white hover:bg-white/10"
                              >
                                View Job
                              </Button>
                            </Link>
                          </>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="saved">
            <Card className="bg-[#0a0a0a] border-[#424242]">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Bookmark className="w-5 h-5 text-[#f57c00]" />
                  Saved Jobs ({savedJobs.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {savedJobs.length === 0 ? (
                  <div className="text-center py-12">
                    <Bookmark className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                    <p className="text-gray-400 mb-4">No saved jobs yet.</p>
                    <Link to="/job-board">
                      <Button className="bg-[#f57c00] hover:bg-[#e65100]">
                        Browse Job Board
                      </Button>
                    </Link>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {savedJobs.map((saved) => (
                      <div
                        key={saved.id}
                        className="bg-[#1a1a1a] p-6 rounded-lg border border-[#424242] hover:border-[#f57c00] transition-all"
                      >
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <h3 className="text-xl font-bold text-white mb-1">
                              {saved.job.title}
                            </h3>
                            <p className="text-gray-300 mb-2">{saved.job.company}</p>
                            <p className="text-gray-400 text-sm mb-4">
                              {saved.job.city}, {saved.job.region}
                            </p>
                            <div className="flex gap-2">
                              <Link to={`/job/${saved.job.id}`}>
                                <Button className="bg-[#f57c00] hover:bg-[#e65100]">
                                  View Details
                                </Button>
                              </Link>
                              <Button
                                variant="ghost"
                                onClick={() => unsaveJobMutation.mutate(saved.id)}
                                className="text-gray-400 hover:text-white"
                              >
                                <Trash2 className="w-4 h-4 mr-2" />
                                Unsave
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="resume">
            <Card className="bg-[#0a0a0a] border-[#424242]">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <FileText className="w-5 h-5 text-[#f57c00]" />
                  My Resume
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label>Professional Headline</Label>
                  <Input
                    value={resumeData.headline || ''}
                    onChange={(e) => setResumeData({...resumeData, headline: e.target.value})}
                    placeholder="e.g., Certified Welder with 5 years ICI experience"
                    className="bg-[#1a1a1a] border-[#424242] text-white mt-2"
                  />
                </div>

                <div>
                  <Label>Summary</Label>
                  <Textarea
                    value={resumeData.summary || ''}
                    onChange={(e) => setResumeData({...resumeData, summary: e.target.value})}
                    placeholder="Brief overview of your experience and skills..."
                    rows={4}
                    className="bg-[#1a1a1a] border-[#424242] text-white mt-2"
                  />
                </div>

                <div>
                  <Label>Certifications & Tickets</Label>
                  <div className="flex gap-2 mt-2 mb-3">
                    <Input
                      value={newTicket}
                      onChange={(e) => setNewTicket(e.target.value)}
                      placeholder="e.g., CWB, Red Seal, WHMIS"
                      className="bg-[#1a1a1a] border-[#424242] text-white"
                      onKeyPress={(e) => e.key === 'Enter' && handleAddTicket()}
                    />
                    <Button onClick={handleAddTicket} className="bg-[#f57c00] hover:bg-[#e65100]">
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {(resumeData.tickets || []).map((ticket, index) => (
                      <Badge key={index} className="bg-[#1a1a1a] border border-[#424242] text-white">
                        {ticket}
                        <button
                          onClick={() => handleRemoveTicket(index)}
                          className="ml-2 hover:text-red-400"
                        >
                          ×
                        </button>
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <Label className="mb-4 block">Work Experience</Label>
                  <div className="space-y-4 mb-4">
                    {(resumeData.experience || []).map((exp, index) => (
                      <div key={index} className="bg-[#1a1a1a] p-4 rounded-lg border border-[#424242]">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="font-bold text-white">{exp.role}</p>
                            <p className="text-gray-400">{exp.employer} • {exp.siteType}</p>
                            <p className="text-sm text-gray-500">{exp.from} - {exp.to || 'Present'}</p>
                            {exp.notes && <p className="text-gray-300 mt-2">{exp.notes}</p>}
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleRemoveExperience(index)}
                            className="text-gray-400 hover:text-red-400"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="bg-[#1a1a1a] p-4 rounded-lg border border-[#424242] space-y-3">
                    <div className="grid md:grid-cols-2 gap-3">
                      <Input
                        value={newExperience.role}
                        onChange={(e) => setNewExperience({...newExperience, role: e.target.value})}
                        placeholder="Role/Title"
                        className="bg-[#0a0a0a] border-[#424242] text-white"
                      />
                      <Input
                        value={newExperience.siteType}
                        onChange={(e) => setNewExperience({...newExperience, siteType: e.target.value})}
                        placeholder="Site Type (e.g., Refinery)"
                        className="bg-[#0a0a0a] border-[#424242] text-white"
                      />
                    </div>
                    <Input
                      value={newExperience.employer}
                      onChange={(e) => setNewExperience({...newExperience, employer: e.target.value})}
                      placeholder="Employer/Company"
                      className="bg-[#0a0a0a] border-[#424242] text-white"
                    />
                    <div className="grid md:grid-cols-2 gap-3">
                      <Input
                        type="month"
                        value={newExperience.from}
                        onChange={(e) => setNewExperience({...newExperience, from: e.target.value})}
                        placeholder="From"
                        className="bg-[#0a0a0a] border-[#424242] text-white"
                      />
                      <Input
                        type="month"
                        value={newExperience.to}
                        onChange={(e) => setNewExperience({...newExperience, to: e.target.value})}
                        placeholder="To (leave empty if current)"
                        className="bg-[#0a0a0a] border-[#424242] text-white"
                      />
                    </div>
                    <Textarea
                      value={newExperience.notes}
                      onChange={(e) => setNewExperience({...newExperience, notes: e.target.value})}
                      placeholder="Description (optional)"
                      rows={2}
                      className="bg-[#0a0a0a] border-[#424242] text-white"
                    />
                    <Button
                      onClick={handleAddExperience}
                      disabled={!newExperience.role.trim()}
                      className="w-full bg-[#424242] hover:bg-[#616161] text-white"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Add Experience
                    </Button>
                  </div>
                </div>

                <Button
                  onClick={() => saveResumeMutation.mutate()}
                  disabled={saveResumeMutation.isPending}
                  className="w-full bg-[#f57c00] hover:bg-[#e65100] text-white py-6"
                >
                  {saveResumeMutation.isPending ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    'Save Resume'
                  )}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="account">
            <Card className="bg-[#0a0a0a] border-[#424242]">
              <CardHeader>
                <CardTitle className="text-white">Account Settings</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-gray-400">Name</p>
                    <p className="text-white font-medium">{user?.full_name}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Email</p>
                    <p className="text-white font-medium">{user?.email}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Account Type</p>
                    <p className="text-white font-medium capitalize">{profile?.role || user?.role}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

export default function TradespersonDashboard() {
  return (
    <ProtectedRoute requiredRole="tradesperson">
      <TradespersonDashboardContent />
    </ProtectedRoute>
  );
}
