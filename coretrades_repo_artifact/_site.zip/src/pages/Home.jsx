
import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Target, Clock, DollarSign, Briefcase } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function Home() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadUser() {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      } catch (error) {
        setUser(null); // Ensure user is null if not logged in or error occurs
      } finally {
        setLoading(false);
      }
    }
    loadUser();
  }, []);

  const handlePostJob = async () => {
    if (loading) return; // Prevent action if user data is still loading

    if (!user) {
      base44.auth.redirectToLogin(createPageUrl('Home'));
      return;
    }

    // Check if user is an employer
    if (user.app_role === 'employer') {
      try {
        // Fetch employer entity associated with the user's email
        // Assuming memberEmails on Employer entity is an array and we're looking for the user's email within it
        const employers = await base44.entities.Employer.filter({ 
          memberEmails: [user.email] 
        });
        
        // If an employer entity is found and it has a 'plan' property (indicating an active plan)
        if (employers.length > 0 && employers[0].plan) {
          navigate(createPageUrl('EmployerJobNew')); // Direct to job posting form
          return;
        }
      } catch (error) {
        console.error('Error checking employer plan:', error);
        // Fallback to HiringServices if there's an API error
      }
    }

    // If not an employer, or employer without a plan, or any error occurred, go to Hiring Services
    navigate(createPageUrl('HiringServices'));
  };

  useEffect(() => {
    document.title = 'CoreTrades | The #1 Platform for North America\'s ICI Trades';
    
    const setMetaTag = (name, content, isProperty = false) => {
      const attribute = isProperty ? 'property' : 'name';
      let meta = document.querySelector(`meta[${attribute}="${name}"]`);
      if (meta) {
        meta.setAttribute('content', content);
      } else {
        meta = document.createElement('meta');
        meta.setAttribute(attribute, name);
        meta.content = content;
        document.head.appendChild(meta);
      }
    };

    setMetaTag('description', 'CoreTrades is the leading platform connecting employers with skilled tradespeople across North America\'s ICI sector. Post jobs, find talent, and build better teams faster.');
    setMetaTag('keywords', 'ICI trades, industrial construction, commercial trades, institutional trades, skilled tradespeople, trades jobs Canada, trades jobs USA, hire electricians, hire welders, trades recruitment platform, CoreTrades');
    
    // Open Graph
    setMetaTag('og:title', 'CoreTrades | The #1 Platform for North America\'s ICI Trades', true);
    setMetaTag('og:description', 'Hire smarter, faster, and more affordably. Built by tradespeople for tradespeople. Connect with verified skilled trades across the ICI sector.', true);
    setMetaTag('og:type', 'website', true);
    setMetaTag('og:url', 'https://coretrades.co', true);
    setMetaTag('og:image', 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68e94290f81cfefa873a4024/215085d1b_backgroundcopy2.jpg', true);
    
    // Twitter Card
    setMetaTag('twitter:card', 'summary_large_image');
    setMetaTag('twitter:title', 'CoreTrades | The #1 Platform for North America\'s ICI Trades');
    setMetaTag('twitter:description', 'Hire smarter, faster, and more affordably. Built by tradespeople for tradespeople.');
    setMetaTag('twitter:image', 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68e94290f81cfefa873a4024/215085d1b_backgroundcopy2.jpg');

    return () => {
      document.title = 'Core Trades Inc.';
    };
  }, []);

  return (
    <div className="bg-[#1a1a1a] min-h-screen">
      <div className="relative min-h-screen">
        <div 
          className="fixed inset-0 z-0"
          style={{
            backgroundImage: `url('https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68e94290f81cfefa873a4024/215085d1b_backgroundcopy2.jpg')`,
            backgroundSize: "cover",
            backgroundPosition: "50% 45%",
            backgroundAttachment: "fixed",
          }}
        />
        
        <div className="fixed inset-0 z-[1] bg-gradient-to-b from-black/30 via-black/20 to-black/10" />

        <section className="relative z-[2] min-h-[78vh] md:min-h-[68vh] flex items-center justify-center">
          <div className="text-center max-w-7xl mx-auto px-6 py-20">
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-black mb-4 leading-tight tracking-tight text-white drop-shadow-[0_2px_6px_rgba(0,0,0,0.55)]">
              North America's Industrial, Commercial & Institutional Trades Job Board.
            </h1>
            <p className="text-lg md:text-xl lg:text-2xl text-zinc-200 mb-8 max-w-3xl mx-auto drop-shadow-[0_1px_4px_rgba(0,0,0,0.45)]">
              Connecting skilled trades professionals and employers across construction, manufacturing, and heavy industry.
            </p>

            <div className="flex flex-col md:flex-row gap-3 md:gap-4 justify-center">
              <Link to={createPageUrl("JobBoard")} className="w-full sm:w-auto">
                <Button className="w-full sm:w-auto bg-[#f57c00] hover:bg-[#e65100] text-white text-base md:text-lg px-8 py-6 rounded-xl transition-all duration-300 hover:shadow-2xl font-bold border-2 border-[#f57c00] hover:border-[#e65100]">
                  Job Board
                </Button>
              </Link>
              <Link to={createPageUrl("ForEmployers")} className="w-full sm:w-auto">
                <Button className="w-full sm:w-auto bg-[#424242] hover:bg-[#616161] text-white text-base md:text-lg px-8 py-6 rounded-xl transition-all duration-300 hover:shadow-lg border-2 border-[#424242] hover:border-[#616161]">
                  For Employers
                </Button>
              </Link>
              <Link to={createPageUrl("ForTradespeople")} className="w-full sm:w-auto">
                <Button className="w-full sm:w-auto bg-[#424242] hover:bg-[#616161] text-white text-base md:text-lg px-8 py-6 rounded-xl transition-all duration-300 hover:shadow-lg border-2 border-[#424242] hover:border-[#616161]">
                  For Tradespeople
                </Button>
              </Link>
              <div className="w-full sm:w-auto">
                <Button 
                  onClick={handlePostJob}
                  disabled={loading}
                  className="w-full sm:w-auto inline-flex items-center justify-center bg-[#f57c00] hover:bg-[#e65100] text-white text-base md:text-lg px-8 py-6 rounded-xl transition-all duration-300 hover:shadow-2xl font-bold border-2 border-[#f57c00] hover:border-[#e65100]"
                >
                  <Briefcase className="w-5 h-5 mr-2" />
                  Post a Job
                </Button>
              </div>
            </div>
          </div>
        </section>

        <section className="relative z-[2] py-20 bg-black/60 backdrop-blur-sm">
          <div className="max-w-7xl mx-auto px-6">
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-black/60 backdrop-blur-md p-8 rounded-xl border border-white/10 hover:border-[#f57c00]/50 transition-all duration-300">
                <div className="w-16 h-16 bg-[#f57c00]/20 rounded-xl flex items-center justify-center mb-6">
                  <Target className="w-8 h-8 text-[#f57c00]" />
                </div>
                <h3 className="text-2xl font-bold mb-4 text-white">ICI Only</h3>
                <p className="text-gray-200 text-lg leading-relaxed">
                  Focused exclusively on industrial, commercial, and institutional sectors.
                </p>
              </div>

              <div className="bg-black/60 backdrop-blur-md p-8 rounded-xl border border-white/10 hover:border-[#f57c00]/50 transition-all duration-300">
                <div className="w-16 h-16 bg-[#f57c00]/20 rounded-xl flex items-center justify-center mb-6">
                  <Clock className="w-8 h-8 text-[#f57c00]" />
                </div>
                <h3 className="text-2xl font-bold mb-4 text-white">Faster Hires</h3>
                <p className="text-gray-200 text-lg leading-relaxed">
                  Pre-verified candidates reduce time-to-fill.
                </p>
              </div>

              <div className="bg-black/60 backdrop-blur-md p-8 rounded-xl border border-white/10 hover:border-[#f57c00]/50 transition-all duration-300">
                <div className="w-16 h-16 bg-[#f57c00]/20 rounded-xl flex items-center justify-center mb-6">
                  <DollarSign className="w-8 h-8 text-[#f57c00]" />
                </div>
                <h3 className="text-2xl font-bold mb-4 text-white">Predictable Pricing</h3>
                <p className="text-gray-200 text-lg leading-relaxed">
                  Flat monthly plans — no recruiter commissions.
                </p>
              </div>
            </div>

            <div className="mt-16 max-w-2xl mx-auto">
              <div className="bg-black/60 backdrop-blur-md p-8 rounded-xl border border-white/10">
                <h3 className="text-2xl font-bold mb-4 text-center text-white">
                  Stay Notified
                </h3>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Input
                    type="email"
                    placeholder="your.email@company.com"
                    className="flex-1 bg-black/40 border-white/20 text-white placeholder:text-gray-400 h-12"
                  />
                  <Button className="bg-[#f57c00] hover:bg-[#e65100] text-white px-8 h-12">
                    Notify Me
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
